<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


Route::get('/', function () {
    return view('welcome');
});

Route::auth();

Route::get('/home', 'HomeController@index');

Route::get('/token', 'Api\TokenController@createJWT');

Route::get('/api/agreement', 'Api\UserController@showAgreement');

//АПИ
Route::group(['middleware'=>'token','namespace' => 'Api','prefix' => '/api/users' ], function (){
    Route::post('/register',['uses'=>'UserController@registerUser']);
    Route::post('/login',['uses'=>'UserController@loginUser']);
    Route::post('/update',['uses'=>'UserController@updateUser']);
    Route::get('/showusers',['uses'=>'UserController@showUsers']);
    Route::post('/update/image',['uses'=>'UserController@updateAvatar']);
    Route::get('/rating',['uses'=>'UserController@getRatingTable']);
    Route::get('/profile/{id?}',['uses'=>'UserController@getMyProfile']);

    Route::get('/{id?}',['uses'=>'PartyController@getUserCreatedParty']);

    Route::put('/update/rating',['uses'=>'UserController@updateRatingUser']);
    Route::put('/notes',['uses'=>'UserController@updateStatusNote']);



});

Route::group(['middleware'=>'token','namespace' => 'Api','prefix' => '/api/parties' ], function (){
    Route::post('/create',['uses'=>'PartyController@createParty']);
    Route::get('/',['uses'=>'PartyController@getParties']);
    Route::post('/reviews/add',['uses'=>'PartyController@addReviewToParty']);
    Route::get('/reviews/{id?}',['uses'=>'PartyController@getReviewsParty']);
    Route::post('/reports',['uses'=>'PartyController@createReports']);
});

Route::get('/api/party/{id?}',['middleware'=>'token','uses' => 'Api\PartyController@getParty']);
Route::post('/api/party/members',['middleware'=>'token','uses' => 'Api\PartyController@addMembersToParty']);

//Админка
Route::group(['middleware' => 'auth','prefix' => '/admin'], function () {
    Route::get('/list-users', ['uses' => 'AdminController@showListAppUsers']);
    Route::get('/list-party', ['uses' => 'AdminController@showListParties']);
    Route::get('/create/party', ['middleware' => 'admin', function () {
        return view('admin.create_party')->with('user', Auth::user());

    }]);
    Route::get('/home', ['middleware' => 'admin', function () {
        return view('admin.home')->with('user', Auth::user());

    }]);
    Route::get('/users/{id?}',['uses' => 'AdminController@getUser']);
    Route::delete('/users/{id?}',['uses' => 'AdminController@deleteUser']);
    Route::put('/users/{id?}',['uses' => 'AdminController@updateAppUser']);

    Route::put('/users/note/{id?}',['uses' => 'AdminController@addNote']);
    Route::delete('/users/ban/{id?}',['uses' => 'AdminController@deleteBan']);

    Route::put('/users/ban/{id?}',['uses' => 'AdminController@banUser']);


    // Вписки
    Route::get('/parties/{id?}',['uses' => 'AdminController@getParty']);
    Route::delete('/parties/{id?}',['uses' => 'AdminController@deleteParty']);
    Route::put('/parties/{id?}',['uses' => 'AdminController@updateParty']);

    Route::post('/parties/create',['uses'=>'AdminController@createParty']);
});





//=========================НОВАЯ ВЕРСИЯ==============================================

Route::group(['middleware'=>'token','namespace' => 'Api\v1','prefix' => '/api/v1/users' ], function (){

    Route::post('/login',['uses'=>'UserController@loginUser']);
    Route::post('/update',['uses'=>'UserController@updateUser']);
    Route::post('/update/image',['uses'=>'UserController@updateAvatar']);
    Route::get('/rating/{access_token?}',['uses'=>'UserController@getRatingTable']);
    Route::get('/profile/{access_token?}',['uses'=>'UserController@getMyProfile']);

    Route::get('/{id?}/{access_token?}',['uses'=>'PartyController@getUserCreatedParty']);

    Route::put('/update/rating',['uses'=>'UserController@updateRatingUser']);
    Route::put('/notes',['uses'=>'UserController@updateStatusNote']);
    Route::put('/check-update-rating',['uses'=>'UserController@checkUpdateRating']);




});
Route::post('/api/v1/users/login',['uses'=>'Api\v1\UserController@loginUser']);
Route::post('/api/v1/users/register',['uses'=>'Api\v1\UserController@registerUser']);
Route::put('/api/v1/users/token/update',['uses'=>'Api\v1\UserController@updateDataTokens']);


Route::group(['middleware'=>'token','namespace' => 'Api\v1','prefix' => '/api/v1/parties' ], function (){
    Route::post('/create',['uses'=>'PartyController@createParty']);
    Route::get('/{access_token?}/',['uses'=>'PartyController@getParties']);
    Route::post('/reviews/add',['uses'=>'PartyController@addReviewToParty']);
    Route::get('/reviews/{id?}/{access_token?}',['uses'=>'PartyController@getReviewsParty']);
    Route::post('/reports',['uses'=>'PartyController@createReports']);
    Route::post('/members',['uses' => 'PartyController@addMembersToParty']);
});

Route::group(['middleware'=>'token','namespace' => 'Api\v1','prefix' => '/api/v1/party' ], function (){
    Route::get('/{id?}/{access_token?}/',['uses' => 'PartyController@getParty']);
});





