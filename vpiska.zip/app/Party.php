<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Party extends Model
{
    public function user(){
        return $this->hasOne('App\AppUser','id','created_id');
    }

    public function members(){
        return $this->hasMany('App\PartyMember','id_party','id');
    }
}
